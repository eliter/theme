from django.apps import AppConfig


class WizardExamplesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.wizard_examples"
